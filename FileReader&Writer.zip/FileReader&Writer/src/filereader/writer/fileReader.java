/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filereader.writer;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;


/**
 *
 * @author aufeuerman
 */
public class fileReader {
    
    private String _toRead;
    //create parameters for each method in parameters
    
    public fileReader (String toRead){
        _toRead = toRead;
    }
    //get the next line of the question
    //do not know if this is needed
    public void getClasses(){ //reader
        //pull all classes from the file
        try{
            String line;
            FileReader fileReader = new FileReader (_toRead);
            BufferedReader buffReader = new BufferedReader(fileReader);
            //runs while there is still another line
            while ((line = buffReader.readLine()) !=null){
                //gets the classes from the file
                String [] splitArray;
                splitArray = line.split(",");
                
                
                
            }
        }catch (IOException ex) {
            System.out.println("The file has the incorrect format");
        }
    }
    public ArrayList getClassSettings() throws FileNotFoundException{ //reader
        //could return class or arrayList
        //pass this a className
        ArrayList<String> classSettings = new ArrayList();
        
        try{
            String line;
            FileReader fileReader = new FileReader (_toRead);
            BufferedReader buffReader = new BufferedReader(fileReader);
            //runs while there is still another line
            if ((line = buffReader.readLine()) !=null){
                //gets the classes from the file
                //splits csv to get information
                String [] splitArray;
                //splits by looking for comma
                splitArray = line.split(",");
                //first split, is the days the class meets
                String meetingDays = splitArray[0];
                classSettings.add(meetingDays);
                //this finds the late factor at which to start
                //penalizing the student for being late
                String lateFactor = splitArray[1];
                classSettings.add(lateFactor);
                //finds  the time the class starts at
                String startTime = splitArray[2];
                classSettings.add(startTime);
                //finds the time the class ends at
                String endTime = splitArray[3];
                //adds each element to an arrayList;
                classSettings.add(endTime);
                System.out.println(classSettings);
                //finds the time the class ends at
            while ((line = buffReader.readLine()) !=null){
                splitArray = line.split(",");
                String studentName = splitArray[0];
                //adds each element to an arrayList;
                classSettings.add(studentName);
                //finds the time the class ends at
                String studentID = splitArray[1];
                //adds each element to an arrayList;
                classSettings.add(studentID);
                //finds the time the class ends at
                String blueToothID = splitArray[2];
                //adds each element to an arrayList;
                classSettings.add(blueToothID);
                
            }  
                System.out.println(classSettings);
         }
            
        }catch (IOException ex) {
            System.out.println("The file has the incorrect format");
        }
        return classSettings;
    }
   /* public ArrayList getStudents(String className){ //reader
        //takes string className
        ArrayList<String> studentInfo = new ArrayList();
        try{
            String line;
            FileReader fileReader = new FileReader (_toRead);
            BufferedReader buffReader = new BufferedReader(fileReader);
            //runs while there is still another line
            
            while ((line = buffReader.readLine()) !=null){
                studentInfo.add(line);
                //gets the classes from the file
                //splits the csv file
                String [] splitArray;
                //splits by the comma
                splitArray = line.split(",");
                
            }
        }catch (IOException ex) {
            System.out.println("The file has the incorrect format");
        }
    }
    public String getAttendance(String studentName, String className){ //reader
        //take student name and class here
        String present = "1";
        String late = "0.5";
        String absent = "0";
        String toReturn = "";
            
        try{
            String line;
            FileReader fileReader = new FileReader (_toRead);
            BufferedReader buffReader = new BufferedReader(fileReader);
            //runs while there is still another line
            while ((line = buffReader.readLine()) !=null){
                //gets the classes from the file
                String [] splitArray;
                splitArray = line.split(",");
                
                boolean isFound = false;
                
                if (isFound){
                    toReturn = absent;
                }else{
                    if(isFound.equals(lateFactor)){
                        toReturn = late;
                    }else{
                        toReturn = present;
                    }
                }
                
            }
        }catch (IOException ex) {
            System.out.println("The file has the incorrect format");
        }
        return toReturn; ///CHANGE THIS
    }
    
   /* public void getFileFormat(){
        //create array list to add lines to 
        ArrayList<String> fileFormat = new ArrayList();
        
        try{
            String line;
            FileReader fileReader = new FileReader (_toRead);
            BufferedReader buffReader = new BufferedReader(fileReader);
            //runs while there is still another line
            while ((line = buffReader.readLine()) !=null){
                
            }
            
        }
        catch (IOException ex) {
            System.out.println("The file has the incorrect format");
        }
    }*/
}