/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filereader.writer;

import java.io.File;
import java.util.ArrayList;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;


/**
 *
 * @author aufeuerman
 */
public class fileWriter {
    private String _toWrite;
    
    public fileWriter(String toWrite){
        _toWrite = toWrite;
    }
    public void markAttendance(String className, String studentName,
                               Double attendence, String data){ //writer
        //takes classname, sutdent name, attendance status
        //write if student if present, tardy or absent over
        //student name
        try{
            String line = "";
            FileWriter fileWriter = new FileWriter (_toWrite);
            BufferedWriter buffWriter = new BufferedWriter(fileWriter);
            
            
            Date d = new Date();
            //buffWriter.write(d);
            
            
            
            
            
            
        }catch (IOException ex) {
            System.out.println("The file has the incorrect format");
        }
    }
    public void addStudent(String studentName, String blueToothID,
                           String studentID, boolean hasBlueToothDevice) throws FileNotFoundException{ //writer
        //takes name, bluetooth id, student id, boolean hasBluetoothDevice
        try{
            String line = "";
            //FileWriter fileWriter = new FileWriter (_toWrite);
            //BufferedWriter buffWriter = new BufferedWriter(fileWriter);
       //     System.out.println("here");
            PrintWriter pw = new PrintWriter(new File(_toWrite));
            StringBuilder sb = new StringBuilder();
            
            /*buffWriter.write(studentName);
            buffWriter.write(blueToothID);
            buffWriter.write(studentID);
            if (hasBlueToothDevice= true){
                buffWriter.write("True");
            }else{
                buffWriter.write("False");
            }
            buffWriter.write(studentName);
            buffWriter.write(blueToothID);
            buffWriter.write(studentID);
            if (hasBlueToothDevice= true){
                buffWriter.write("True");
            }else{
                buffWriter.write("False");
            }*/
            sb.append(studentName);
            sb.append(',');
            sb.append(blueToothID);
            sb.append(',');
            sb.append(studentID);
            sb.append(',');
            if (hasBlueToothDevice= true){
                sb.append("True");
            }else{
                sb.append("False");
            }
            
            pw.write(sb.toString());
            pw.close();
            System.out.println("done!");
            
            
        }catch (IOException ex) {
            System.out.println("The Student Input Was Not Correct.");
        }
        
    }
    public void addClass(String className, String classStart,
                         String duration, boolean meetMonday,boolean meetTuesday,
                         boolean meetWednesday, boolean meetThursday,
                         boolean meetFriday, String lateFactor){ //writer
        //takes class- blank file, except first line
        //first line is setting
        //take classname, meet time, end time, meet days(five booleans), late buffer
        
        try{
            String line = "";
            FileWriter fileWriter = new FileWriter (_toWrite);
            BufferedWriter buffWriter = new BufferedWriter(fileWriter);
            
            File newFile = new File(className +".txt");
            
            buffWriter.write(classStart);
            buffWriter.write(duration);
            if (meetMonday = true){
                buffWriter.write("M");
            }else if (meetTuesday = true){
                buffWriter.write("T");
            }else if (meetWednesday = true){
                buffWriter.write("W");
            }else if(meetThursday = true){
                buffWriter.write("Th");
            }else if(meetFriday = true){
                buffWriter.write("F");
            }else{
                buffWriter.write("");
            }
            buffWriter.write(lateFactor);
            
            
            
        }catch (IOException ex) {
            System.out.println("The Class Format Was Not Correct.");
        }
    }
    }
    /*public void writeFileFormat() throws IOException{
        ArrayList<String> fileFormat = new ArrayList();
        if (!file.exists()){
            file.createNewFile();
            
        }
        try{
            String line;
            FileWriter FW = new FileWriter (_toWrite);
            BufferedWriter buffReader = new BufferedWriter(FW);
            
            FW.write(File);
            FW.close();
            
            System.out.println("Your class attendace has been created.");
        
        }    
        catch (IOException ex) {
            System.out.println("Was unable to write to file");
        }
    
    
}*/
