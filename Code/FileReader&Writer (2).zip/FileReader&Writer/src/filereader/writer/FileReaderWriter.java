/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filereader.writer;

import java.io.FileNotFoundException;

/**
 *
 * @author aufeuerman
 */
public class FileReaderWriter {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        //Use this to test methods
        //Makes sure can read from csv
        //Make sure it writes to the same csv
        //implement classes (both fileReader and fileWriter)
        fileReader newReader = new fileReader("CS275.csv");
        System.out.println(newReader.getClassSettings());
       fileWriter newWriter = new fileWriter ("CS175.csv");
       newWriter.addStudent("josh", "123", "123", true);
        
    }
    
}
