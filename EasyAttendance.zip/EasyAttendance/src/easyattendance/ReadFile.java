/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package easyattendance;

import java.util.ArrayList;

public class ReadFile {
    
    private ReadFile() {
        
    }
    
    public static ArrayList getClasses(){
        ArrayList<String> classList = new ArrayList();
        classList.add("Cs173");
        classList.add("Cs174");
        classList.add("Cs275");
        
        return classList;
    }
    
    public static ArrayList getClassSettings(String className){
        // class : name, meet days, meet time, end time, late buffer
        ArrayList<String> settings = new ArrayList();
//        settings.add("true:false:true:false:true");
//        settings.add("11:00");
//        settings.add("11:50");
//        settings.add("5");
        
        return settings;
    }
    
    public static void saveClassSettings(String className, String duration,
            boolean meetMonday, boolean meetTuesday, boolean meetWednesday,
            boolean meetThursday, boolean meetFriday, double lateBuffer){
        System.out.println("Saved Class Settings!");
    }
    
    public static ArrayList getStudents(String className){
//        File classFile = new File("/src/easyattendance/text/" + className + ".csv");
        ArrayList<String> studentList = new ArrayList();
        studentList.add("Mitchell");
        studentList.add("Liam");
        studentList.add("Austin");
        return studentList;
    }
    
    public static ArrayList getStudentSettings(String className, String studentName){
//        File classFile = new File("/src/easyattendance/text/" + className + ".csv");
        ArrayList<String> settings = new ArrayList();
        settings.add("Mitchell");
        settings.add("SID696969");
        settings.add("BID1515222");
        settings.add("true");
        
        return settings;
    }
    
    public static void saveStudentSettings(String studentName, String studentID, String device){
        System.out.println("Saved Student Settings!");
    }
    
    public static String getAttendance(String studentName, String className){
        // get student attendace for a class from a file
        String attendance;
        attendance = "1:5";
        
        return attendance;
    }
    
    public static void markAttendance( String className, String studentName, String attendance){
        
    }
    
    public static void addClass(String className){
        System.out.println("Added " + className);
    }
    
    public static void addStudent(String studentName, String bluetoothID, boolean hbd){
        System.out.println(studentName + "has bluetooth ID " + bluetoothID + " " + hbd);
    }
}
